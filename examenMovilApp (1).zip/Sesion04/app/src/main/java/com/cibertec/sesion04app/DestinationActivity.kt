package com.cibertec.sesion04app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView


class DestinationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_destination)

        val txtCliente :  TextView = findViewById(R.id.txtCliente)
        val txtDni :  TextView = findViewById(R.id.txtDni)
        val txtMPago : TextView = findViewById(R.id.txtMpago)
        val txtPlatoDia :TextView= findViewById(R.id.txtPlatoDia)
        val txtCostoPlato :  TextView = findViewById(R.id.txtCostoPlato)
        val txtBolsas :  TextView = findViewById(R.id.txtBolsas)
        val txtDelivery :  TextView = findViewById(R.id.txtDelivery)
        val txtAdicional :  TextView = findViewById(R.id.txtAdicional)

        val txtTotal: TextView = findViewById(R.id.txtTotal)
        intent.extras?.apply {
            txtCliente.text = getString("KEY_NOMBRE") ?: "Desconocido"
            txtDni.text = getString("KEY_DNI") ?: "Desconocido"
            txtMPago.text = getString("KEY_MPAGO") ?: "Desconocido"
            txtPlatoDia.text= getString("KEY_PLATO") ?: "Desconocido"
            txtCostoPlato.text =  getString("KEY_COSTOPLATO") ?:"Desconocido"
            txtBolsas.text = getString("KEY_BOLSAS")
            txtDelivery.text = getString("KEY_DELIVERY")
            txtAdicional.text = getString("KEY_ADICIONAL")
            txtTotal.text = getString("KEY_TOTAL")

        }
    }
}

