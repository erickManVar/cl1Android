package com.cibertec.sesion04app

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edDni: EditText = findViewById(R.id.edDni)
        val edNombre: EditText = findViewById(R.id.edNombre)
        val rbEfectivo: RadioButton = findViewById(R.id.rbEfectivo)
        val rbTarjeta: RadioButton = findViewById(R.id.rbTarjeta)
        val chkDelivery: CheckBox = findViewById(R.id.chkDelivery)
        val chkBolsa: CheckBox = findViewById(R.id.chkBolsa)
        val btnCalcular: Button = findViewById(R.id.btnCalcular)
        val btnImprimir: Button = findViewById(R.id.btnImprimir)
        val spCourse: AutoCompleteTextView = findViewById(R.id.spCourse2)
        val txtTotal: TextView = findViewById(R.id.txtTotal)
        val txtTadicional: TextView = findViewById(R.id.textTadicional)
        val txtBolsas: TextView = findViewById(R.id.txtBolsas)
        val txtDelivery: TextView = findViewById(R.id.txtDelivery)
        val txtMenu: TextView = findViewById(R.id.txtMenu)


        val coursesList: List<String> = listOf("Ceviche", "Arroz con Pollo", "Lomo Saltado")
        val coursesPrices = mapOf("Ceviche" to 18, "Arroz con Pollo" to 17, "Lomo Saltado" to 20)

        spCourse.setAdapter(ArrayAdapter(this, R.layout.item_course, coursesList))

        var totalFinal: Double = 0.0
        var totalAdicional: Double = 0.0
        var menuDelDia = ""

        spCourse.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            menuDelDia = coursesList[position]
            val coursePrice = coursesPrices[menuDelDia] ?: 0
            totalFinal = totalAdicional + coursePrice
            txtTotal.text = totalFinal.toString()
        }

        btnCalcular.setOnClickListener {
            totalAdicional = 0.0
            if (chkDelivery.isChecked) {
                totalAdicional += 5
                txtDelivery.text = "5"
            } else {
                txtDelivery.text = "0"
            }
            if (chkBolsa.isChecked) {
                totalAdicional += 1
                txtBolsas.text = "1"
            } else {
                txtBolsas.text = "0"
            }
            totalFinal = totalAdicional + (coursesPrices[menuDelDia] ?: 0)
            txtTadicional.text = totalAdicional.toString()
            txtTotal.text = totalFinal.toString()
            val coursePrice = coursesPrices[menuDelDia] ?: 0
            txtMenu.text = coursePrice.toString()
            val costoAdicional  = totalAdicional
        }


        btnImprimir.setOnClickListener {
            val dni = edDni.text.toString()
            val nombre = edNombre.text.toString()
            val mPago = if (rbEfectivo.isChecked) "Efectivo" else "Tarjeta"
            val totalAdicional = totalFinal.toString()
            if (dni.isEmpty() || nombre.isEmpty() || (!chkDelivery.isChecked && !chkBolsa.isChecked)) {
                Toast.makeText(this, "Por favor, complete todos los campos.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }


            val intent = Intent(this, DestinationActivity::class.java)
            intent.putExtra("KEY_NOMBRE", nombre)
            intent.putExtra("KEY_DNI", dni)
            intent.putExtra("KEY_PLATO", menuDelDia)

            intent.putExtra("KEY_MPAGO", mPago)
            intent.putExtra("KEY_COSTOPLATO", totalFinal.toString())

            var bolsas = txtBolsas.text



            intent.putExtra("KEY_BOLSAS",txtBolsas.text)
            intent.putExtra("KEY_DELIVERY",txtDelivery.text)
            intent.putExtra("KEY_ADICIONAL",txtTadicional.text)
            intent.putExtra("KEY_TOTAL", txtTotal.text)

            //intent.putExtra("KEY_MENU",txtTotal.text)


            startActivity(intent)
        }
    }
}
